/// <reference types="vite/client" />
/// <reference types="react-scripts" />
declare module 'react-slick';